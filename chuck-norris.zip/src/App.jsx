import React, { Component } from "react";
import { connect } from "react-redux";
import CategoryButtons from "./components/CategoryList";
import RandomJoke from "./components/RandomJoke";
import Avatar from "@mui/material/Avatar";
import Logo from "./img/Chuck.jpg";
// import "./App.css";
import "./styles/App.css";
import Typography from "@mui/material/Typography";
import { createTheme, ThemeProvider } from "@mui/material";

const theme = createTheme({
  typography: {
    fontFamily: ["Roboto Condensed", "cursive"].join(","),
  },
});

class App extends Component {
  render() {
    return (
      <ThemeProvider theme={theme}>
        <div className="container">
          <div className="content">
            <div className="header">
              <Typography variant="h3">
                Welcome to Chuck Norris' random joke generator
              </Typography>
              <div className="avatar-chuck">
                <Avatar
                  alt="Chuck Norris"
                  src={Logo}
                  sx={{ width: 304, height: 304 }}
                />
              </div>
            </div>
            <RandomJoke />
            <Typography variant="h5">Category:</Typography>

            <CategoryButtons />

            <div className="joke-container">
              {this.props.randomjoke.randomjoke}
            </div>
            <hr />
          </div>
        </div>
      </ThemeProvider>
    );
  }
}
const mapStateToProps = (state) => {
  return {
    randomjoke: state.randomjoke,
  };
};

export default connect(mapStateToProps)(App);
