import React, { Component } from "react";
import { connect } from "react-redux";
import { getRandomJoke } from "../Redux/actions/actions";
import Button from "@mui/material/Button";

class RandomJoke extends Component {
  generateJoke() {
    this.props.getRandomJoke();
  }
  render() {
    return (
      <div>
        <Button
          variant="contained"
          color="success"
          className="btn btn-primary"
          onClick={() => this.generateJoke()}
          style={{ margin: 10 }}
        >
          GENERATE RANDOM JOKE
        </Button>
      </div>
    );
  }
  j;
}

//update in Redux and merge into props
const mapStateToProps = (state) => {
  return {
    randomjoke: state.randomjoke,
  };
};

//dispatch an action getRandomJoke
const mapDispatchToProps = (dispatch) => {
  return {
    getRandomJoke: () => dispatch(getRandomJoke()),
  };
};

export default connect(mapStateToProps, mapDispatchToProps)(RandomJoke);
